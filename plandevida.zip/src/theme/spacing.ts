const Spacing = {

  xs: 4,

  sm: 8,

  md: 12,

  lg: 16,

  xl: 20,

  xxl: 24,

  xxxl: 32,

  huge: 40,

};

export default Spacing;